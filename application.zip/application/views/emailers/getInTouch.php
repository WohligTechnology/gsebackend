<div>
<h4>Get In Touch Details</h4>

<p>
<span>
  <b>Category Name :</b>
</span>
<span>
  <?php echo $mailer->categoryname;?>
</span>
</p>


<p>
<span>
  <b>First Name :</b>
</span>
<span>
  <?php echo $mailer->firstname;?>
</span>
</p>


<p>
<span>
  <b>Last Name :</b>
</span>
<span>
  <?php echo $mailer->lastname;?>
</span>
</p>

<p>
<span>
  <b>Email :</b>
</span>
<span>
  <?php echo $mailer->email;?>
</span>
</p>

<p>
<span>
  <b>Contact No :</b>
</span>
<span>
  <?php echo $mailer->phone;?>
</span>
</p>

<p>
<span>
  <b>Comment :</b>
</span>
<span>
  <?php echo $mailer->comment;?>
</span>
</p>

<p>
<span>
  <b>Enquiry For :</b>
</span>
<span>
  <?php echo $mailer->enquiryfor;?>
</span>
</p>

<p>
<span>
  <b>Location :</b>
</span>
<span>
  <?php echo $mailer->location;?>
</span>
</p>

<p>
<span>
  <b>Number of People:</b>
</span>
<span>
  <?php echo $mailer->noofpeople;?>
</span>
</p>

<p>
<span>
  <b>Start Date :</b>
</span>
<span>
  <?php echo $mailer->startdate;?>
</span>
</p>


<p>
<span>
  <b>End Date :</b>
</span>
<span>
  <?php echo $mailer->enddate;?>
</span>
</p>
</div>

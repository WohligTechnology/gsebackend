<?php 
echo $this->load->view('backend/header');
echo $this->load->view('backend/'.$page);
echo $this->load->view('backend/footer');
?>